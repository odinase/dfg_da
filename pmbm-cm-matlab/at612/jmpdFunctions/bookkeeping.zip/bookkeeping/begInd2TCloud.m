function tCloud = begInd2TCloud(begInd,nElement)

% Function to find lengths of each partition given start index of each partition
% Written by Edmund Brekke during December 2007
% @ begInd:     Beginning index of each partition
% @ nElement:   Total number of elements in full list
% > tCloud:     Number of elements in each partition

if(max(begInd > nElement + 1))
    error('Highest begInd cannot be higher than number of elements plus one');
end
if(~issorted(begInd))
   error('begInd is not sorted'); 
end

% Partition lengths are found by differencing the beginning indices

if(~isempty(begInd) && nElement > 0)
    begInd = [begInd,nElement];
    tCloud = diff(begInd);
    if(tCloud(end) < 0)
        tCloud(end) = 0;
    end
elseif(nElement == 0)
    tCloud = [];
else
    error('If begInd is empty there cannot be more than zero elements.');
end