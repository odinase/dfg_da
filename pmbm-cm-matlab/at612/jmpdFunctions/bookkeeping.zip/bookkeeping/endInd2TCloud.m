function tCloud = endInd2TCloud(endInd)

% Function to find lengths of each partition given end indices of the partitions
% Written by Edmund Brekke December 2007
% @ endInd:     End of each partition
% > tCloud:     Length of each partition


endInd = [0,endInd];
tCloud = diff(endInd);

if(~issorted(endInd))
   error('endInd is not sorted'); 
end